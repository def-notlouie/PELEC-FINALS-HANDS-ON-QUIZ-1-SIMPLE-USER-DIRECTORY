# User Directory App

A React app that fetches users from `https://jsonplaceholder.typicode.com/users` and displays the first 5 (name, email, company name).

## Run it

```bash
npm install
npm start
```

Then open http://localhost:3000

## How it meets the requirements
- Fetches data with the native **Fetch API** (no Axios).
- Uses **async/await** inside the fetch function.
- Fetch runs inside **useEffect()** on mount.
- **useState()** manages `users`, `loading`, and `error`.
- Shows "Loading users..." while fetching, "Failed to fetch users." on error.
- Slices the response to only the first 5 users.
